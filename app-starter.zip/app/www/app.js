var app = new App(1, "Starter App", "1.0.0", "HIBRIDO","HOMOLOGACAO");

app.initApp();